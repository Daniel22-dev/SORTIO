#!/usr/bin/env node
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { findChromiumPath } from './chromium-path.mjs';

const root=path.resolve('.');
const dist=path.join(root,'dist');
const appHtml=await fsp.readFile(path.join(dist,'index.html'),'utf8');
const appJs=(await fsp.readFile(path.join(dist,'app.js'),'utf8')).replace(/<\/script/gi,'<\\/script');
const platformJs=(await fsp.readFile(path.join(dist,'ghrab','ghrab-platform.js'),'utf8')).replace("new URL('./ghrab/ghrab-platform.js', location.href)","new URL('https://example.test/app/ghrab/ghrab-platform.js')");
const platformCss=await fsp.readFile(path.join(dist,'ghrab','ghrab-platform.css'),'utf8');
const accessCss=await fsp.readFile(path.join(dist,'access','access-gate.css'),'utf8');
const canary='GARP-XSS-CANARY-20260903-SORTIO-FINAL-16';
const hostile=process.env.GARP_SAFE_BASELINE==='1'?'safe-synthetic-id':`x\"><img src=x onerror=\"window.__sortioXss='${canary}'\"><span data-x=\"`;
const hostileLong=`${'seat-'.repeat(25)}${hostile}`;
const hostileText=process.env.GARP_SAFE_BASELINE==='1'?'Bezpečný syntetický text':`\"><img data-garp-hostile-text=\"1\" src=x onerror=\"window.__sortioTextXss=1\">`;
const now=new Date().toISOString();
const rawData={schema:'sortio-data-v5',version:5,selectedClassId:`class-${hostile}`,classes:[{id:`class-${hostile}`,name:hostileText,schoolYear:'2026/27',archived:false,createdAt:now,updatedAt:now,students:[{id:`student-${hostile}`,firstName:'Ada',lastName:'Testovací',present:true,archived:false,groupLevel:'B',createdAt:now,updatedAt:now},{id:'student-safe-2',firstName:'Bořek',lastName:'Syntetický',present:true,archived:false,groupLevel:'B',createdAt:now,updatedAt:now}],drawState:{remainingIds:[`student-${hostile}`,'student-safe-2'],cycle:0,lastDraw:null},drawHistory:[],engagementHistory:[{id:`eng-${hostile}`,studentId:`student-${hostile}`,kind:'answer',label:hostileText,createdAt:now}],currentGroups:[{id:`group-${hostile}`,name:hostileText,studentIds:[`student-${hostile}`,'student-safe-2'],spokespersonId:`student-${hostile}`,roleAssignments:{'Mluvčí':`student-${hostile}`},topic:hostileText,createdAt:now}],groupHistory:[],lastGroupConfig:{mode:'size',value:2,smartMode:'random'},groupRules:{together:[],apart:[],pins:{[`student-${hostile}`]:0}},roleCatalog:['Mluvčí'],topicCatalog:[],roleHistory:[{id:`role-${hostile}`,groupId:`group-${hostile}`,studentId:`student-${hostile}`,role:'Mluvčí',createdAt:now}],seatingPlan:{template:'rows',rows:2,columns:2,seats:[{id:hostileLong,row:0,column:0,studentId:`student-${hostile}`,blocked:false,locked:false}],updatedAt:now},toolState:{scores:[{id:`team-${hostile}`,name:hostileText,score:1}],decisionOptions:[],updatedAt:now}}],aliases:{},createdAt:now,updatedAt:now,integrity:{saveCount:0,lastSavedAt:null}};
const memoryPrelude=`<script data-garp-hostile-prelude>(()=>{class M{constructor(){this.m=new Map()}get length(){return this.m.size}key(i){return [...this.m.keys()][i]??null}getItem(k){return this.m.has(String(k))?this.m.get(String(k)):null}setItem(k,v){this.m.set(String(k),String(v))}removeItem(k){this.m.delete(String(k))}clear(){this.m.clear()}};const store=new M();store.setItem('sortio.data.v5',${JSON.stringify(JSON.stringify(rawData))});Object.defineProperty(window,'localStorage',{value:store,configurable:true});Object.defineProperty(window,'sessionStorage',{value:new M(),configurable:true});window.__sortioXss=null;window.__sortioTextXss=null;window.__GARP_ERRORS__=[];addEventListener('error',e=>window.__GARP_ERRORS__.push({message:String(e.message||e.error||'error'),stack:String(e.error?.stack||''),file:String(e.filename||''),line:e.lineno||0,col:e.colno||0}));addEventListener('unhandledrejection',e=>window.__GARP_ERRORS__.push(String(e.reason?.stack||e.reason)));window.alert=()=>{};window.confirm=()=>true;window.prompt=()=>'';window.open=()=>null;try{if(globalThis.ServiceWorkerContainer?.prototype?.register){globalThis.ServiceWorkerContainer.prototype.register=async()=>({update:async()=>{},addEventListener:()=>{},installing:null,waiting:null,active:null});}}catch{}})();<\/script>`;
function transformHtml(source){
  let html=source
    .replace(/data-ghrab-access=["']checking["']/gi,'data-ghrab-access="granted"')
    .replace(/<script\b(?=[^>]*data-ghrab-access-bootstrap)[^>]*>[\s\S]*?<\/script>/gi,'')
    .replace(/type=["']application\/ghrab-protected["']/gi,'type="text/javascript"')
    .replace(/\sdata-ghrab-protected(?:=["'][^"']*["'])?/gi,'')
    .replace(/<link\b[^>]*href=["']\.\/access\/access-gate\.css["'][^>]*>/gi,`<style data-garp-inline-access>${accessCss}</style>`)
    .replace(/<link\b[^>]*href=["']\.\/ghrab\/ghrab-platform\.css["'][^>]*>/gi,`<style data-garp-inline-platform>${platformCss}</style>`)
    .replace(/<script\b[^>]*src=["']\.\/ghrab\/ghrab-platform\.js["'][^>]*><\/script>/gi,()=>`<script data-garp-inline-platform>${platformJs}<\/script>`)
    .replace(/<script\b[^>]*src=["']\.\/app\.js["'][^>]*><\/script>/gi,()=>`<script data-garp-inline-app>${appJs}<\/script>`);
  return html.replace(/<head\b[^>]*>/i,m=>`${m}\n${memoryPrelude}`);
}
const html=transformHtml(appHtml);if(process.env.GARP_DUMP_HTML)fs.writeFileSync(process.env.GARP_DUMP_HTML,html);
if(!/http-equiv=["']Content-Security-Policy/i.test(html))throw new Error('Hostile-render harness omylem odstranil CSP.');
async function waitJson(url,accept=()=>true){
  for(let i=0;i<220;i++){
    try{
      const r=await fetch(url);
      if(r.ok){
        const value=await r.json();
        if(accept(value))return value;
      }
    }catch{}
    await sleep(50);
  }
  throw new Error(`Chromium debug timeout: ${url}`);
}
function hasPageTarget(targets){return Array.isArray(targets)&&targets.some(t=>t?.type==='page'&&t?.webSocketDebuggerUrl)}
class Cdp{constructor(url){this.ws=new WebSocket(url);this.seq=0;this.pending=new Map();this.ready=new Promise((res,rej)=>{this.ws.onopen=res;this.ws.onerror=rej});this.ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&this.pending.has(m.id)){const p=this.pending.get(m.id);this.pending.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result)}};}async call(method,params={}){await this.ready;return new Promise((resolve,reject)=>{const id=++this.seq;this.pending.set(id,{resolve,reject});this.ws.send(JSON.stringify({id,method,params}))})}async eval(expression){const r=await this.call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result?.value}close(){try{this.ws.close()}catch{}}}
const debugPort=13700+(process.pid%400),profile=`/tmp/sortio-garp-hostile-${process.pid}`;fs.rmSync(profile,{recursive:true,force:true});
const chrome=spawn(findChromiumPath(),['--headless=new','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--disable-background-networking','--disable-extensions','--no-first-run','--mute-audio','--remote-allow-origins=*',`--remote-debugging-port=${debugPort}`,`--user-data-dir=${profile}`,'about:blank'],{stdio:'ignore',detached:true});let client;
try{
  await waitJson(`http://127.0.0.1:${debugPort}/json/version`);
  const targets=await waitJson(`http://127.0.0.1:${debugPort}/json`,hasPageTarget);
  const pageTarget=targets.find(t=>t?.type==='page'&&t?.webSocketDebuggerUrl);
  client=new Cdp(pageTarget.webSocketDebuggerUrl);
  await client.call('Runtime.enable');await client.call('Page.enable');const tree=await client.call('Page.getFrameTree');await client.call('Page.setDocumentContent',{frameId:tree.frameTree.frame.id,html});
  let ready=false;for(let i=0;i<240;i++){ready=Boolean(await client.eval("document.readyState==='complete'&&document.documentElement.dataset.appReady==='true'"));if(ready)break;await sleep(50)}if(!ready){const debug=await client.eval(`(()=>({ready:document.readyState,access:document.documentElement.dataset.ghrabAccess,appReady:document.documentElement.dataset.appReady||'',errors:window.__GARP_ERRORS__||[],body:document.body?.textContent?.slice(0,300)||''}))()`);throw new Error('SORTIO se v hostile-render harnessu nespustilo: '+JSON.stringify(debug));}
  for(const route of ['classes','groups','roles','seating','tools']){await client.eval(`activateRoute(${JSON.stringify(route)},{save:false,scroll:false})`);await sleep(120);}
  const result=await client.eval(`(()=>({canary:window.__sortioXss,textCanary:window.__sortioTextXss,onerrorCount:document.querySelectorAll('[onerror]').length,onfocusCount:document.querySelectorAll('[onfocus]').length,hostileMarkupCount:[...document.querySelectorAll('body *:not(script):not(style)')].filter(el=>el.outerHTML.includes(${JSON.stringify(canary)})).length,hostileTextElementCount:document.querySelectorAll('img[data-garp-hostile-text]').length,students:document.querySelectorAll('[data-student-id]').length,stored:localStorage.getItem('sortio.data.v5')||'',errors:window.__GARP_ERRORS__||[]}))()`);
  const stored=JSON.parse(result.stored);const identifiers=[];for(const c of stored.classes||[]){identifiers.push(c.id);for(const s of c.students||[])identifiers.push(s.id);for(const g of c.currentGroups||[])identifiers.push(g.id);for(const seat of c.seatingPlan?.seats||[])identifiers.push(seat.id);for(const e of c.engagementHistory||[])identifiers.push(e.id);for(const t of c.toolState?.scores||[])identifiers.push(t.id)}const safe=/^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/;const unsafeIds=identifiers.filter(id=>!safe.test(String(id)));
  const report={schema:'sortio-garp-hostile-render-v1',version:'1.1.17',cspPreserved:true,storageHarness:'in-memory localStorage equivalent',canaryExecuted:result.canary===canary,textCanaryExecuted:result.textCanary===1,onerrorCount:result.onerrorCount,onfocusCount:result.onfocusCount,hostileMarkupCount:result.hostileMarkupCount,hostileTextElementCount:result.hostileTextElementCount,renderedStudentRefs:result.students,unsafePersistedIdentifiers:unsafeIds.length,runtimeErrors:result.errors,status:'passed'};if(report.canaryExecuted||report.textCanaryExecuted||report.onerrorCount||report.onfocusCount||report.hostileMarkupCount||report.hostileTextElementCount||unsafeIds.length||result.errors.length)report.status='failed';await fsp.mkdir(path.join(root,'test-results'),{recursive:true});await fsp.writeFile(path.join(root,'test-results','garp-hostile-render.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(report.status!=='passed')process.exitCode=1;
}finally{client?.close();if(chrome.exitCode===null){try{process.kill(-chrome.pid,'SIGTERM')}catch{}}await Promise.race([new Promise(r=>chrome.once('exit',r)),sleep(1500)]);if(chrome.exitCode===null){try{process.kill(-chrome.pid,'SIGKILL')}catch{}}await sleep(100);fs.rmSync(profile,{recursive:true,force:true,maxRetries:5,retryDelay:100})}
