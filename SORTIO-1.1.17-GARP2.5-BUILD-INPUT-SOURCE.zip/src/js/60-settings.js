function renderSettingsDataSummary(){const classes=getClasses({includeArchived:true});const active=getClasses();const students=classes.reduce((sum,item)=>sum+classStudents(item,{includeArchived:true}).length,0);const draws=classes.reduce((sum,item)=>sum+item.drawHistory.length,0);const groups=classes.reduce((sum,item)=>sum+item.groupHistory.length,0);const roles=classes.reduce((sum,item)=>sum+item.roleHistory.length,0);const seating=classes.filter(item=>item.seatingPlan?.seats?.some(seat=>seat.studentId)).length;const engagement=classes.reduce((sum,item)=>sum+(item.engagementHistory?.length||0),0);const values={storedClasses:active.length,archivedClasses:classes.length-active.length,storedStudents:students,storedDraws:draws,storedGroups:groups,storedRoles:roles,storedSeating:seating,storedEngagement:engagement};for(const[id,value]of Object.entries(values)){const node=$(`[data-data-stat="${id}"]`);if(node)node.textContent=value}const confirmInput=$('#confirmSetting');if(confirmInput)confirmInput.checked=App.settings.confirmDestructive!==false}
function bindSettings(){
  const themeSegment=$('#themeSegment');
  themeSegment?.addEventListener('click',event=>{
    const button=event.target.closest('[data-value]');
    if(!button)return;
    App.settings.theme=button.dataset.value;
    applyTheme();
    saveSettings();
  });
  $('#motionSetting')?.addEventListener('change',event=>{
    App.settings.motion=event.target.checked;
    applyMotion();
    saveSettings();
  });
  $('#confirmSetting')?.addEventListener('change',event=>{
    App.settings.confirmDestructive=event.target.checked;
    saveSettings();
  });
  $('#themeToggle')?.addEventListener('click',()=>{
    const order=['dark','light','system'];
    App.settings.theme=order[(order.indexOf(App.settings.theme)+1)%order.length];
    applyTheme();
    saveSettings();
    toast(`Motiv: ${App.settings.theme==='dark'?'tmavý':App.settings.theme==='light'?'světlý':'podle systému'}`,'success');
    recordEvent('setting_change',{setting:'theme',value:App.settings.theme});
  });
  $('#motionToggle')?.addEventListener('click',()=>{
    App.settings.motion=!App.settings.motion;
    applyMotion();
    saveSettings();
    recordEvent('setting_change',{setting:'motion',value:App.settings.motion});
  });
  $('#fullscreenBtn')?.addEventListener('click',async()=>{
    try{
      if(document.fullscreenElement)await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
      recordEvent('fullscreen',{active:!!document.fullscreenElement});
    }catch(error){captureError(error,'fullscreen');toast('Celou obrazovku se nepodařilo aktivovat. Použijte F11.','error')}
  });
  $('#exportBackup')?.addEventListener('click',exportBackup);
  $('#backupFile')?.addEventListener('change',async event=>{
    const file=event.target.files?.[0];
    if(!file)return;
    try{const imported=await importBackup(file);if(imported)toast('Záloha byla načtena.','success')}
    catch(error){toast(error.message,'error')}
    event.target.value='';
  });
  $('#clearAllData')?.addEventListener('click',()=>{
    if(!App.settings.confirmDestructive||confirm('Opravdu vymazat všechny třídy, historii, pravidla, role, skóre a zasedací plány?')){
      clearAllData();toast('Všechna lokální data byla vymazána.','success');
    }
  });
  $('#resetSettings')?.addEventListener('click',()=>{
    clearSettings();
    App.settings={theme:'dark',motion:true,confirmDestructive:true};
    applyTheme();applyMotion();renderSettingsDataSummary();
    toast('Preference byly obnoveny.','success');
  });
}
function applyTheme(){const preferred=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';document.documentElement.dataset.theme=App.settings.theme==='system'?preferred:App.settings.theme;$$('#themeSegment button').forEach(button=>button.classList.toggle('active',button.dataset.value===App.settings.theme))}
function applyMotion(){
  document.documentElement.dataset.motion=App.settings.motion?'on':'off';
  const input=$('#motionSetting');
  if(input)input.checked=App.settings.motion;
  $('#motionToggle')?.classList.toggle('active',App.settings.motion);
}
