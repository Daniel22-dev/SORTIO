function eligibleStudents(classItem=getSelectedClass()){return classStudents(classItem,{presentOnly:true})}
function syncDrawDeck(classItem=getSelectedClass()){
  if(!classItem)return[];
  const eligible=eligibleStudents(classItem);
  const eligibleIds=new Set(eligible.map(item=>item.id));
  const remaining=[];
  const seen=new Set();
  for(const id of classItem.drawState.remainingIds||[]){
    if(eligibleIds.has(id)&&!seen.has(id)){remaining.push(id);seen.add(id);}
  }
  if(Number(classItem.drawState.cycle||0)>0){
    const drawnThisCycle=new Set((classItem.drawHistory||[])
      .filter(item=>item.noRepeat&&Number(item.cycle||0)===Number(classItem.drawState.cycle||0))
      .flatMap(item=>item.selectedIds||[]));
    const newlyEligible=eligible.map(item=>item.id).filter(id=>!seen.has(id)&&!drawnThisCycle.has(id));
    remaining.push(...shuffle(newlyEligible));
  }
  classItem.drawState.remainingIds=remaining;
  return remaining;
}
function resetDrawCycle(classItem=getSelectedClass(),{persist=true}={}){if(!classItem)return;classItem.drawState.remainingIds=shuffle(eligibleStudents(classItem).map(item=>item.id));classItem.drawState.cycle=Number(classItem.drawState.cycle||0)+1;classItem.drawState.lastDraw=null;touchClass(classItem);if(persist)saveData({render:false,event:'draw_cycle_reset'});return classItem.drawState.remainingIds}
function resolveStudents(ids,classItem=getSelectedClass()){const map=new Map(classItem?.students.map(item=>[item.id,item])||[]);return ids.map(id=>map.get(id)).filter(Boolean)}
function performDraw({mode='single',count=1,noRepeat=true}={}){const classItem=getSelectedClass();if(!classItem)throw new Error('Nejprve vyberte třídu.');const eligible=eligibleStudents(classItem);if(!eligible.length)throw new Error('Ve třídě není žádný přítomný student.');let selected=[];let exhausted=false;if(mode==='order'){selected=shuffle(eligible);if(noRepeat){classItem.drawState.remainingIds=[];exhausted=true}}else if(noRepeat){syncDrawDeck(classItem);if(!classItem.drawState.remainingIds.length)resetDrawCycle(classItem,{persist:false});count=Math.max(1,Math.min(Number(count)||1,classItem.drawState.remainingIds.length));const chosenIds=classItem.drawState.remainingIds.splice(0,count);selected=resolveStudents(chosenIds,classItem);exhausted=classItem.drawState.remainingIds.length===0}else{selected=shuffle(eligible).slice(0,Math.max(1,Math.min(Number(count)||1,eligible.length)))}const record={id:uid('draw'),createdAt:nowIso(),mode,count:selected.length,noRepeat,cycle:classItem.drawState.cycle||0,selectedIds:selected.map(item=>item.id),selectedNames:selected.map(item=>item.displayName)};classItem.drawState.lastDraw=record;classItem.drawHistory.unshift(record);classItem.drawHistory=classItem.drawHistory.slice(0,HISTORY_LIMITS.draw);touchClass(classItem);saveData({render:false,event:'draw_perform'});recordEvent('draw',{mode,count:selected.length,noRepeat,exhausted});return{selected,record,remaining:classItem.drawState.remainingIds.length,exhausted}}
function undoLastDraw(){const classItem=getSelectedClass();const last=classItem?.drawState?.lastDraw;if(!classItem||!last)return false;if(last.noRepeat){const eligibleIds=new Set(eligibleStudents(classItem).map(item=>item.id));const restore=last.selectedIds.filter(id=>eligibleIds.has(id)&&!classItem.drawState.remainingIds.includes(id));classItem.drawState.remainingIds=[...restore,...classItem.drawState.remainingIds]}classItem.drawHistory=classItem.drawHistory.filter(item=>item.id!==last.id);classItem.drawState.lastDraw=null;touchClass(classItem);saveData({render:false,event:'draw_undo'});recordEvent('draw_undo',{count:last.selectedIds.length});return true}
